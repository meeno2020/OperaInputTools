"""
流程配置模块
负责流程配置的数据结构和保存/加载
"""
import json
import os


class WorkflowConfig:
    def __init__(self):
        self.steps = []
    
    def add_step(self, step_type, name=None, seconds=None):
        """
        添加流程步骤
        :param step_type: 步骤类型 ('button', 'field', 'key', 'delay')
        :param name: 步骤名称（按钮名、字段名、按键名）
        :param seconds: 延迟秒数（仅delay类型需要）
        :return: 添加的步骤字典
        """
        step = {"type": step_type}
        
        if step_type == "delay":
            step["seconds"] = seconds if seconds is not None else 1
        else:
            step["name"] = name
        
        self.steps.append(step)
        return step
    
    def remove_step(self, index):
        """
        删除流程步骤
        :param index: 步骤索引
        :return: 是否删除成功
        """
        if 0 <= index < len(self.steps):
            del self.steps[index]
            return True
        return False
    
    def move_step(self, from_index, to_index):
        """
        移动流程步骤位置
        :param from_index: 原位置
        :param to_index: 目标位置
        :return: 是否移动成功
        """
        if 0 <= from_index < len(self.steps) and 0 <= to_index < len(self.steps):
            step = self.steps.pop(from_index)
            self.steps.insert(to_index, step)
            return True
        return False
    
    def get_steps(self):
        """获取所有流程步骤"""
        return self.steps.copy()
    
    def clear_steps(self):
        """清空所有步骤"""
        self.steps = []
    
    def save_workflow(self, filepath="workflow.json"):
        """
        保存流程配置到JSON文件
        :param filepath: 保存路径
        :return: 是否保存成功
        """
        try:
            workflow_data = {"workflow": self.steps}
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(workflow_data, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"保存流程配置失败: {e}")
            return False
    
    def load_workflow(self, filepath="workflow.json"):
        """
        从JSON文件加载流程配置
        :param filepath: 文件路径
        :return: 是否加载成功
        """
        try:
            if not os.path.exists(filepath):
                return False
            
            with open(filepath, 'r', encoding='utf-8') as f:
                workflow_data = json.load(f)
            
            if "workflow" in workflow_data:
                self.steps = workflow_data["workflow"]
            else:
                self.steps = workflow_data
            
            return True
        except Exception as e:
            print(f"加载流程配置失败: {e}")
            return False
    
    def get_step_count(self):
        """获取流程步骤数量"""
        return len(self.steps)
    
    def get_step(self, index):
        """
        获取指定步骤
        :param index: 步骤索引
        :return: 步骤字典
        """
        if 0 <= index < len(self.steps):
            return self.steps[index]
        return None

