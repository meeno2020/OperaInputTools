"""
创建发布包脚本
将打包好的程序打包成zip文件，方便分发
"""
import os
import sys
import shutil
import zipfile
from datetime import datetime

def create_release_package():
    """创建发布包"""
    print("\n" + "="*60)
    print("创建发布包")
    print("="*60 + "\n")
    
    # 检查打包目录是否存在
    dist_dir = "dist/Opera Input Tools"
    if not os.path.exists(dist_dir):
        print("错误：找不到打包目录！")
        print(f"请先运行打包脚本：python build_exe.py")
        return False
    
    # 检查exe文件是否存在
    exe_file = os.path.join(dist_dir, "Opera Input Tools.exe")
    if not os.path.exists(exe_file):
        print("错误：找不到可执行文件！")
        print(f"请先运行打包脚本：python build_exe.py")
        return False
    
    # 创建发布包目录
    release_dir = "release"
    if not os.path.exists(release_dir):
        os.makedirs(release_dir)
    
    # 生成版本号（使用日期时间）
    version = datetime.now().strftime("%Y%m%d_%H%M%S")
    package_name = f"OperaInputTools_v{version}"
    zip_path = os.path.join(release_dir, f"{package_name}.zip")
    
    print(f"正在创建发布包：{package_name}.zip")
    print(f"源目录：{dist_dir}")
    print(f"目标文件：{zip_path}\n")
    
    # 创建zip文件
    try:
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # 遍历目录并添加所有文件
            for root, dirs, files in os.walk(dist_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    # 计算相对路径
                    arcname = os.path.relpath(file_path, os.path.dirname(dist_dir))
                    print(f"  添加: {arcname}")
                    zipf.write(file_path, arcname)
        
        # 获取文件大小
        file_size = os.path.getsize(zip_path)
        file_size_mb = file_size / (1024 * 1024)
        
        print("\n" + "="*60)
        print("✓ 发布包创建成功！")
        print("="*60)
        print(f"\n文件位置：{zip_path}")
        print(f"文件大小：{file_size_mb:.2f} MB")
        print(f"\n使用说明：")
        print(f"  1. 将 {package_name}.zip 解压到任意位置")
        print(f"  2. 运行解压后的 OperaInputTools.exe")
        print(f"  3. 无需安装Python或任何其他环境")
        print(f"\n提示：")
        print(f"  - 可以将整个解压后的文件夹复制到U盘")
        print(f"  - 可以在任何Windows 10/11机器上运行")
        print(f"  - 首次运行可能需要几秒钟启动时间")
        
        return True
        
    except Exception as e:
        print(f"\n✗ 创建发布包失败：{e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = create_release_package()
    sys.exit(0 if success else 1)

