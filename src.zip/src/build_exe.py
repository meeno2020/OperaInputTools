"""
打包脚本 - 将程序打包成可执行文件
使用 PyInstaller 打包
"""
import os
import sys
import subprocess

def check_pyinstaller():
    """检查是否已安装 PyInstaller"""
    try:
        import PyInstaller
        print(f"✓ PyInstaller 已安装 (版本: {PyInstaller.__version__})")
        return True
    except ImportError:
        print("✗ PyInstaller 未安装")
        print("正在安装 PyInstaller...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
            print("✓ PyInstaller 安装成功")
            return True
        except subprocess.CalledProcessError:
            print("✗ PyInstaller 安装失败")
            return False

def build_exe():
    """打包程序"""
    print("\n" + "="*60)
    print("PyAutoGUI 自动化输入程序 - 打包工具")
    print("="*60 + "\n")
    
    # 检查 PyInstaller
    if not check_pyinstaller():
        print("\n错误：无法安装 PyInstaller，请手动安装：")
        print("  pip install pyinstaller")
        return False
    
    # 打包命令（使用文件夹模式，包含所有依赖）
    cmd = [
        "pyinstaller",
        "--name=Opera Input Tools",
        "--onedir",  # 文件夹模式（包含所有依赖，适合分发到无Python环境的机器）
        "--windowed",  # 无控制台窗口（GUI程序）
        "--icon=NONE",  # 如果有图标文件，可以改为 --icon=icon.ico
        "--clean",  # 清理临时文件
        "--noconfirm",  # 不询问覆盖
        # 包含所有必要的模块
        "--hidden-import=keyboard",
        "--hidden-import=pynput",
        "--hidden-import=PIL",
        "--hidden-import=PIL.Image",
        "--hidden-import=PIL.ImageGrab",
        "--hidden-import=pandas",
        "--hidden-import=openpyxl",
        "--hidden-import=pyautogui",
        "--hidden-import=winsound",
        "--hidden-import=resource_path",
        "--hidden-import=advanced_locator",
        "--hidden-import=button_locator",
        "--hidden-import=data_loader",
        "--hidden-import=workflow_config",
        "--hidden-import=workflow_executor",
        "--hidden-import=v5_executor",
        "--hidden-import=cv2",
        "--hidden-import=numpy",
        "--hidden-import=mss",
        # 收集所有子模块
        "--collect-all=keyboard",
        "--collect-all=pynput",
        "--collect-all=pandas",
        "--collect-all=pyautogui",
        "--collect-all=PIL",
        "--collect-all=cv2",
        "--collect-all=numpy",
        "--collect-all=mss",
        "main.py"
    ]
    
    # 如果 button_screenshots 目录存在，则包含它
    if os.path.exists("button_screenshots"):
        cmd.insert(6, "--add-data=button_screenshots;button_screenshots")
        print("✓ 检测到 button_screenshots 目录，将包含在打包中")
    else:
        print("⚠ button_screenshots 目录不存在，将不包含在打包中（程序会自动创建）")
    
    print("开始打包...")
    print(f"命令: {' '.join(cmd)}\n")
    
    try:
        subprocess.check_call(cmd)
        print("\n" + "="*60)
        print("✓ 打包成功！")
        print("="*60)
        print("\n程序包位置：")
        print("  dist/Opera Input Tools/")
        print("\n可执行文件：")
        print("  dist/Opera Input Tools/Opera Input Tools.exe")
        print("\n重要提示：")
        print("  - 这是一个完整的程序包，包含所有依赖")
        print("  - 可以将整个文件夹复制到任何Windows机器上运行")
        print("  - 目标机器不需要安装Python或任何其他环境")
        print("  - 首次运行可能需要几秒钟启动时间")
        print("\n分发建议：")
        print("  - 将 dist/Opera Input Tools/ 文件夹压缩成zip")
        print("  - 或者运行 create_release_package.py 创建发布包")
        return True
    except subprocess.CalledProcessError as e:
        print(f"\n✗ 打包失败：{e}")
        return False
    except FileNotFoundError:
        print("\n✗ 错误：找不到 pyinstaller 命令")
        print("请确保已正确安装 PyInstaller")
        return False

if __name__ == "__main__":
    success = build_exe()
    sys.exit(0 if success else 1)

