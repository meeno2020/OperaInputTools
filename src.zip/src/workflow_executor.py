"""
流程执行模块
负责执行自动化输入流程
"""
import pyautogui
import time
import threading
import os
import winsound
from pathlib import Path

from advanced_locator import AdvancedButtonLocator


class WorkflowExecutor:
    def __init__(self, buttons, data_loader, workflow_config, callback=None, search_range=100, show_click_position=False, play_sound=True):
        """
        初始化流程执行器
        :param buttons: 按钮坐标字典
        :param data_loader: DataLoader实例
        :param workflow_config: WorkflowConfig实例
        :param callback: 进度回调函数，参数为(current_row, total_rows, message)
        :param search_range: 坐标周围搜索范围（像素），默认100像素
        :param show_click_position: 是否显示鼠标点击位置提示
        :param play_sound: 是否在每行执行完成后播放提示音，默认True
        """
        self.buttons = buttons
        self.data_loader = data_loader
        self.workflow_config = workflow_config
        self.callback = callback
        self.search_range = search_range  # 坐标周围搜索范围
        self.show_click_position = show_click_position  # 是否显示点击位置
        self.play_sound = play_sound  # 是否播放提示音
        
        self.is_running = False
        self.is_paused = False
        self.should_stop = False
        self.execution_thread = None
        
        # 设置pyautogui延迟
        pyautogui.PAUSE = 0.1  # 默认操作间隔0.1秒
    
    def _show_click_position(self, x, y, button_name=""):
        """
        显示鼠标点击位置提示（通过回调通知主线程显示）
        :param x: X坐标
        :param y: Y坐标
        :param button_name: 按钮名称
        """
        if not self.show_click_position:
            return
        
        # 通过回调通知主线程显示点击位置
        # 使用特殊标记让主线程知道这是点击位置信息
        if self.callback:
            # 使用特殊格式标记，主线程会解析并显示
            self.callback(0, 0, f"__CLICK_POS__:{button_name}:{x}:{y}")
    
    def _safe_locate_on_screen(self, image_path, region=None, confidence=None, grayscale=False):
        """
        安全地调用 locateOnScreen，支持 confidence 参数提高识别精度
        :param image_path: 图像路径
        :param region: 搜索区域 (left, top, width, height)，可选
        :param confidence: 置信度阈值（0-1），可选，需要安装 opencv-python
        :param grayscale: 是否使用灰度匹配，可选
        :return: 找到的位置，如果未找到返回 None
        """
        try:
            # 尝试使用 confidence 参数（如果提供了）
            kwargs = {}
            if confidence is not None:
                kwargs['confidence'] = confidence
            if grayscale:
                kwargs['grayscale'] = grayscale
            
            if region:
                location = pyautogui.locateOnScreen(image_path, region=region, **kwargs)
            else:
                location = pyautogui.locateOnScreen(image_path, **kwargs)
            return location
        except pyautogui.ImageNotFoundException:
            # 图像未找到，返回 None
            return None
        except TypeError as e:
            # 如果 confidence 参数不支持（未安装 opencv-python），回退到不使用 confidence
            error_msg = str(e).lower()
            if 'confidence' in error_msg or 'unexpected keyword' in error_msg:
                try:
                    # 回退到不使用 confidence 的方式
                    if region:
                        location = pyautogui.locateOnScreen(image_path, region=region)
                    else:
                        location = pyautogui.locateOnScreen(image_path)
                    return location
                except:
                    return None
            return None
        except Exception as e:
            # 其他异常，记录但不抛出（避免中断流程）
            error_msg = str(e).lower()
            # 如果是 confidence 相关错误，尝试不使用 confidence
            if 'confidence' in error_msg or 'opencv' in error_msg:
                try:
                    if region:
                        location = pyautogui.locateOnScreen(image_path, region=region)
                    else:
                        location = pyautogui.locateOnScreen(image_path)
                    return location
                except:
                    return None
            # 其他异常也返回 None，让程序继续运行
            return None
    
    def start(self, start_row=0):
        """
        开始执行流程
        :param start_row: 开始执行的行号（从0开始，0表示从第一行开始）
        """
        if self.is_running:
            return False
        
        if not self.data_loader.is_loaded():
            if self.callback:
                self.callback(0, 0, "Error: Please load data file first")
            return False
        
        if len(self.workflow_config.get_steps()) == 0:
            if self.callback:
                self.callback(0, 0, "Error: Please configure workflow first")
            return False
        
        if len(self.buttons) == 0:
            if self.callback:
                self.callback(0, 0, "Error: Please locate buttons first")
            return False
        
        # 验证开始行号
        total_rows = self.data_loader.get_row_count()
        if start_row < 0 or start_row >= total_rows:
            if self.callback:
                self.callback(0, 0, f"Error: Invalid start row (should be between 1-{total_rows})")
            return False
        
        self.start_row = start_row
        self.is_running = True
        self.is_paused = False
        self.should_stop = False
        
        self.execution_thread = threading.Thread(target=self._execute_workflow, daemon=True)
        self.execution_thread.start()
        return True
    
    def pause(self):
        """暂停执行"""
        self.is_paused = True
    
    def resume(self):
        """继续执行（暂停后继续，等待2秒）"""
        # 在单独线程中等待2秒，避免阻塞GUI
        def resume_after_delay():
            if self.callback:
                self.callback(0, 0, "Preparing to resume, waiting 2 seconds...")
            time.sleep(2)
            self.is_paused = False
            if self.callback:
                self.callback(0, 0, "Resuming execution")
        
        # 在后台线程中执行延迟
        resume_thread = threading.Thread(target=resume_after_delay, daemon=True)
        resume_thread.start()
    
    def stop(self):
        """停止执行"""
        self.should_stop = True
        self.is_paused = False
    
    def _wait_for_resume(self):
        """等待恢复执行"""
        while self.is_paused and not self.should_stop:
            time.sleep(0.1)
    
    def _play_notification_sound(self):
        """
        播放柔和的通知提示音（类似特斯拉的提示音）
        使用800Hz频率，持续150ms，产生柔和短促的声音
        """
        if not self.play_sound:
            return
        
        try:
            # 特斯拉风格的柔和提示音：
            # 频率：800Hz（柔和的中音频率）
            # 持续时间：150ms（短促但不突兀）
            # 使用 winsound.Beep 在 Windows 上播放
            winsound.Beep(800, 150)
        except Exception:
            # 如果播放失败（如非Windows系统），静默忽略
            pass
    
    def _execute_workflow(self):
        """执行流程（在单独线程中运行）"""
        try:
            total_rows = self.data_loader.get_row_count()
            steps = self.workflow_config.get_steps()
            
            # 从指定的开始行执行
            start_row = getattr(self, 'start_row', 0)
            if start_row > 0 and self.callback:
                self.callback(0, 0, f"Starting from row {start_row + 1} (total {total_rows} rows)")
            
            for row_index in range(start_row, total_rows):
                if self.should_stop:
                    break
                
                # 等待恢复
                self._wait_for_resume()
                if self.should_stop:
                    break
                
                # 获取当前行数据
                row_data = self.data_loader.get_row(row_index)
                if row_data is None:
                    continue
                
                # 执行流程步骤
                for step in steps:
                    if self.should_stop:
                        break
                    
                    # 等待恢复
                    self._wait_for_resume()
                    if self.should_stop:
                        break
                    
                    step_type = step.get("type")
                    
                    if step_type == "button":
                        # 点击按钮（优先使用精确图像识别）
                        button_name = step.get("name")
                        if button_name in self.buttons:
                            button_data = self.buttons[button_name]
                            
                            clicked = False
                            match = None
                            image_path = button_data.get("image_path")
                            if image_path:
                                image_file = Path(image_path)
                                if not image_file.is_absolute():
                                    image_file = (Path(os.getcwd()) / image_file).resolve()
                                if image_file.exists():
                                    search_region = None
                                    region_data = button_data.get("screenshot_region")
                                    if isinstance(region_data, dict) and {"left", "top", "width", "height"}.issubset(region_data.keys()):
                                        search_region = (
                                            region_data["left"],
                                            region_data["top"],
                                            region_data["width"],
                                            region_data["height"],
                                        )
                                    locate_attempts = [
                                        dict(match_threshold=0.9, timeout=2.0, retry_interval=0.2, search_region=search_region, allow_scroll=False),
                                        dict(match_threshold=0.86, timeout=4.0, retry_interval=0.25, search_region=None, allow_scroll=False),
                                        dict(match_threshold=0.82, timeout=5.0, retry_interval=0.3, search_region=None, allow_scroll=True, scroll_step=-350, scroll_pause=0.25, max_scroll_attempts=4),
                                    ]
                                    for attempt in locate_attempts:
                                        try:
                                            match = AdvancedButtonLocator.locate_button(
                                                image_file,
                                                match_threshold=attempt.get("match_threshold", 0.85),
                                                timeout=attempt.get("timeout", 4.0),
                                                retry_interval=attempt.get("retry_interval", 0.25),
                                                search_region=attempt.get("search_region"),
                                                allow_scroll=attempt.get("allow_scroll", False),
                                                scroll_step=attempt.get("scroll_step", -350),
                                                scroll_pause=attempt.get("scroll_pause", 0.25),
                                                max_scroll_attempts=attempt.get("max_scroll_attempts", 4),
                                            )
                                            if match:
                                                break
                                        except Exception as e:
                                            if self.callback:
                                                self.callback(row_index + 1, total_rows, f"Warning: advanced locator error for {button_name}: {str(e)}")
                                            match = None
                                            break
                                    if match and self.callback:
                                        self.callback(row_index + 1, total_rows, f"Advanced locator match for {button_name}: score {match.score:.2f}, count {match.match_count}")
                            
                            if match:
                                center_x, center_y = match.center
                                self._show_click_position(center_x, center_y, button_name)
                                pyautogui.click(center_x, center_y)
                                clicked = True
                                if self.callback:
                                    self.callback(
                                        row_index + 1,
                                        total_rows,
                                        f"Click {button_name} (advanced locator)",
                                    )
                            
                            # 回退到存储的坐标
                            if not clicked and "x" in button_data and "y" in button_data:
                                try:
                                    saved_x = button_data["x"]
                                    saved_y = button_data["y"]
                                    self._show_click_position(saved_x, saved_y, button_name)
                                    pyautogui.click(saved_x, saved_y)
                                    clicked = True
                                    if self.callback:
                                        self.callback(row_index + 1, total_rows, f"Click {button_name} (Coordinate location: {saved_x},{saved_y})")
                                except Exception as e:
                                    if self.callback:
                                        self.callback(row_index + 1, total_rows, f"Coordinate location failed: {str(e)}")
                            
                            if not clicked and image_path and os.path.exists(image_path):
                                # 最后尝试使用 PyAutoGUI 的 locateOnScreen
                                location = self._safe_locate_on_screen(image_path)
                                if location:
                                    center_x = int(round(location.left + location.width / 2.0))
                                    center_y = int(round(location.top + location.height / 2.0))
                                    self._show_click_position(center_x, center_y, button_name)
                                    pyautogui.click(center_x, center_y)
                                    clicked = True
                                    if self.callback:
                                        self.callback(row_index + 1, total_rows, f"Click {button_name} (fallback locateOnScreen)")
                            
                            if not clicked:
                                if self.callback:
                                    self.callback(row_index + 1, total_rows, f"Warning: Cannot find button {button_name}, please check if screenshot exists or relocate")
                    
                    elif step_type == "field":
                        # 输入字段数据
                        field_name = step.get("name")
                        if field_name in row_data:
                            field_value = str(row_data[field_name])
                            pyautogui.write(field_value, interval=0.05)
                            if self.callback:
                                self.callback(row_index + 1, total_rows, f"Input {field_name}: {field_value}")
                    
                    elif step_type == "key":
                        # 键盘操作
                        key_name = step.get("name")
                        # 检查是否是组合键（包含+号）
                        if "+" in key_name:
                            # 组合键，使用hotkey
                            parts = key_name.split("+")
                            # 转换为小写并处理特殊键
                            keys = []
                            for part in parts:
                                part = part.strip().lower()
                                # 处理修饰键名称
                                if part == "ctrl":
                                    keys.append("ctrl")
                                elif part == "alt":
                                    keys.append("alt")
                                elif part == "win":
                                    keys.append("win")
                                elif part == "shift":
                                    keys.append("shift")
                                else:
                                    # 普通按键，直接添加（已经是小写）
                                    keys.append(part)
                            try:
                                pyautogui.hotkey(*keys)
                            except Exception as e:
                                # 如果hotkey失败，尝试使用press
                                if self.callback:
                                    self.callback(row_index + 1, total_rows, f"Warning: Failed to execute hotkey {key_name}: {str(e)}")
                        else:
                            # 单个按键
                            try:
                                pyautogui.press(key_name.lower())
                            except Exception as e:
                                if self.callback:
                                    self.callback(row_index + 1, total_rows, f"Warning: Failed to press key {key_name}: {str(e)}")
                        if self.callback:
                            self.callback(row_index + 1, total_rows, f"Press Key {key_name}")
                    
                    elif step_type == "delay":
                        # 延迟
                        seconds = step.get("seconds", 1)
                        elapsed = 0
                        while elapsed < seconds and not self.should_stop:
                            time.sleep(0.1)
                            elapsed += 0.1
                            self._wait_for_resume()
                        if self.callback:
                            self.callback(row_index + 1, total_rows, f"Delay {seconds} seconds")
                
                # 每行数据执行完成后播放提示音
                if not self.should_stop:
                    self._play_notification_sound()
                    if self.callback:
                        self.callback(row_index + 1, total_rows, f"Row {row_index + 1} execution completed")
            
            # 执行完成
            self.is_running = False
            if self.callback:
                if self.should_stop:
                    self.callback(total_rows, total_rows, "Execution stopped")
                else:
                    self.callback(total_rows, total_rows, "Execution completed")
                    
        except Exception as e:
            self.is_running = False
            if self.callback:
                self.callback(0, 0, f"Execution error: {str(e)}")
    
    def is_executing(self):
        """检查是否正在执行"""
        return self.is_running
    
    def is_paused_state(self):
        """检查是否处于暂停状态"""
        return self.is_paused

