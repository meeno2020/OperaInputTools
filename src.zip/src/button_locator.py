"""
按钮定位模块
负责监听Shift+W快捷键，记录按钮坐标和截图
"""
import pyautogui
import json
import os
from threading import Thread
import keyboard
import time

# 尝试导入资源路径工具（如果存在）
try:
    from resource_path import get_screenshot_dir
except ImportError:
    # 如果导入失败，使用默认函数
    def get_screenshot_dir():
        """默认的截图目录获取函数"""
        screenshot_dir = os.path.join(os.getcwd(), "button_screenshots")
        if not os.path.exists(screenshot_dir):
            try:
                os.makedirs(screenshot_dir)
            except:
                pass
        return screenshot_dir
from PIL import ImageGrab


class ButtonLocator:
    def __init__(self, callback=None, screenshot_dir="button_screenshots"):
        """
        初始化按钮定位器
        :param callback: 坐标记录回调函数，参数为(button_name, x, y, image_path, error_msg)
        :param screenshot_dir: 按钮截图保存目录
        """
        self.callback = callback
        self.is_listening = False
        self.button_count = 0
        self.current_button_index = 0
        self.buttons = {}
        self.hotkey_registered = False
        
        # 使用资源路径工具获取截图目录（支持打包后的环境）
        if screenshot_dir == "button_screenshots":
            # 使用默认目录，支持打包后的环境
            self.screenshot_dir = get_screenshot_dir()
        else:
            # 使用指定的目录
            self.screenshot_dir = os.path.abspath(screenshot_dir)
            # 确保目录存在
            try:
                if not os.path.exists(self.screenshot_dir):
                    os.makedirs(self.screenshot_dir)
            except Exception as e:
                print(f"创建截图目录失败: {e}")
                # 回退到默认目录
                self.screenshot_dir = get_screenshot_dir()
        
    def start_listening(self, button_count):
        """
        开始监听按钮定位
        :param button_count: 需要定位的按钮数量
        """
        if self.is_listening:
            return False
            
        self.button_count = button_count
        self.current_button_index = 0
        self.buttons = {}
        self.is_listening = True
        
        # 注册全局热键 Shift+W
        try:
            keyboard.add_hotkey('shift+w', self._on_hotkey_pressed)
            self.hotkey_registered = True
            return True
        except Exception as e:
            print(f"注册热键失败: {e}")
            self.is_listening = False
            return False
    
    def stop_listening(self):
        """停止监听按钮定位"""
        self.is_listening = False
        if self.hotkey_registered:
            try:
                keyboard.remove_hotkey('shift+w')
            except:
                pass
            self.hotkey_registered = False
    
    def _on_hotkey_pressed(self):
        """处理Shift+W热键按下事件"""
        if not self.is_listening:
            return
            
        if self.current_button_index >= self.button_count:
            return
        
        # 获取当前鼠标位置
        x, y = pyautogui.position()
        
        # 生成按钮名称
        button_name = f"按钮{self.current_button_index + 1}"
        
        # 截取按钮区域（鼠标位置周围100x40像素）
        screenshot_width = 100
        screenshot_height = 40
        left = max(0, x - screenshot_width // 2)
        top = max(0, y - screenshot_height // 2)
        
        # 确保截图目录存在
        if not os.path.exists(self.screenshot_dir):
            try:
                os.makedirs(self.screenshot_dir)
            except Exception as e:
                error_msg = f"创建截图目录失败: {e}"
                print(error_msg)
                # 如果创建目录失败，仍然保存坐标
                self.buttons[button_name] = {"x": x, "y": y}
                if self.callback:
                    self.callback(button_name, x, y, None, error_msg)
                self.current_button_index += 1
                if self.current_button_index >= self.button_count:
                    self.stop_listening()
                return
        
        try:
            # 截取屏幕区域（使用PIL的ImageGrab，更可靠）
            screenshot = ImageGrab.grab(bbox=(left, top, left + screenshot_width, top + screenshot_height))
            
            # 保存截图
            image_filename = f"{button_name}.png"
            image_path = os.path.join(self.screenshot_dir, image_filename)
            screenshot.save(image_path)
            
            # 验证文件是否成功保存
            if not os.path.exists(image_path):
                raise Exception(f"截图文件保存失败: {image_path}")
            
            # 记录按钮信息（包含坐标和截图路径）
            self.buttons[button_name] = {
                "x": x,
                "y": y,
                "image_path": image_path,
                "screenshot_region": {
                    "left": left,
                    "top": top,
                    "width": screenshot_width,
                    "height": screenshot_height
                }
            }
            
            # 调用回调函数
            if self.callback:
                self.callback(button_name, x, y, image_path, None)
            
        except Exception as e:
            error_msg = f"截图保存失败: {str(e)}"
            print(error_msg)
            import traceback
            traceback.print_exc()  # 打印详细错误信息
            # 如果截图失败，仍然保存坐标（兼容旧方式）
            self.buttons[button_name] = {"x": x, "y": y}
            if self.callback:
                self.callback(button_name, x, y, None, error_msg)
        
        self.current_button_index += 1
        
        # 如果所有按钮都已定位，自动停止
        if self.current_button_index >= self.button_count:
            self.stop_listening()
    
    def get_buttons(self):
        """获取所有已定位的按钮坐标"""
        return self.buttons.copy()
    
    def save_buttons(self, filepath="buttons.json"):
        """
        保存按钮坐标和截图路径到JSON文件
        :param filepath: 保存路径
        """
        try:
            # 保存时使用相对路径（如果截图在同一目录下）
            save_data = {}
            file_dir = os.path.dirname(os.path.abspath(filepath))
            
            for name, button_data in self.buttons.items():
                save_data[name] = button_data.copy()
                # 如果截图路径是绝对路径，转换为相对路径（相对于配置文件目录）
                if "image_path" in save_data[name] and save_data[name]["image_path"]:
                    img_path = save_data[name]["image_path"]
                    if os.path.isabs(img_path):
                        # 尝试转换为相对路径
                        try:
                            rel_path = os.path.relpath(img_path, file_dir)
                            save_data[name]["image_path"] = rel_path
                        except:
                            # 如果转换失败，保持绝对路径
                            pass
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(save_data, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"保存按钮坐标失败: {e}")
            return False
    
    def load_buttons(self, filepath="buttons.json"):
        """
        从JSON文件加载按钮坐标和截图路径
        :param filepath: 文件路径
        """
        try:
            if not os.path.exists(filepath):
                return False
            with open(filepath, 'r', encoding='utf-8') as f:
                loaded_data = json.load(f)
            
            # 处理相对路径，转换为绝对路径
            file_dir = os.path.dirname(os.path.abspath(filepath))
            self.buttons = {}
            
            for name, button_data in loaded_data.items():
                # 如果截图路径是相对路径，转换为绝对路径
                if "image_path" in button_data and button_data["image_path"]:
                    img_path = button_data["image_path"]
                    if not os.path.isabs(img_path):
                        # 尝试转换为绝对路径
                        abs_path = os.path.join(file_dir, img_path)
                        if os.path.exists(abs_path):
                            button_data["image_path"] = abs_path
                        else:
                            # 如果相对路径不存在，尝试使用原始路径
                            if not os.path.exists(img_path):
                                # 如果都不存在，可能文件已丢失，保留路径但标记
                                pass
                
                self.buttons[name] = button_data
            
            return True
        except Exception as e:
            print(f"加载按钮坐标失败: {e}")
            return False
    
    def get_progress(self):
        """
        获取定位进度
        :return: (已定位数量, 总数量)
        """
        return (self.current_button_index, self.button_count)
    
    def is_complete(self):
        """检查是否所有按钮都已定位"""
        return self.current_button_index >= self.button_count and self.button_count > 0
    
    def rename_button(self, old_name, new_name):
        """
        重命名按钮
        :param old_name: 原按钮名称
        :param new_name: 新按钮名称
        :return: 是否重命名成功
        """
        if old_name not in self.buttons:
            return False
        
        if new_name in self.buttons and new_name != old_name:
            return False  # 新名称已存在
        
        # 重命名
        button_data = self.buttons.pop(old_name)
        self.buttons[new_name] = button_data
        
        # 如果存在截图文件，重命名截图文件
        if "image_path" in button_data and button_data["image_path"]:
            old_image_path = button_data["image_path"]
            if os.path.exists(old_image_path):
                new_image_path = os.path.join(self.screenshot_dir, f"{new_name}.png")
                try:
                    os.rename(old_image_path, new_image_path)
                    button_data["image_path"] = new_image_path
                except Exception as e:
                    print(f"重命名截图文件失败: {e}")
        
        return True
    
    def get_button_names(self):
        """获取所有按钮名称列表"""
        return list(self.buttons.keys())

