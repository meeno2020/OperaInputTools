"""
程序测试脚本
测试核心功能是否正常工作
"""
import os
import sys

def test_imports():
    """测试所有模块是否能正常导入"""
    print("=" * 60)
    print("测试1: 模块导入")
    print("=" * 60)
    
    try:
        import tkinter
        print("✓ tkinter 导入成功")
    except ImportError as e:
        print(f"✗ tkinter 导入失败: {e}")
        return False
    
    try:
        import pyautogui
        print("✓ pyautogui 导入成功")
    except ImportError as e:
        print(f"✗ pyautogui 导入失败: {e}")
        return False
    
    try:
        import pandas
        print("✓ pandas 导入成功")
    except ImportError as e:
        print(f"✗ pandas 导入失败: {e}")
        return False
    
    try:
        import keyboard
        print("✓ keyboard 导入成功")
    except ImportError as e:
        print(f"✗ keyboard 导入失败: {e}")
        return False
    
    try:
        from PIL import ImageGrab
        print("✓ Pillow 导入成功")
    except ImportError as e:
        print(f"✗ Pillow 导入失败: {e}")
        return False
    
    try:
        import cv2
        print("✓ opencv-python 已安装 (版本:", cv2.__version__, ")")
        print("  → 可以使用高精度图像识别（confidence参数）")
    except ImportError:
        print("⚠ opencv-python 未安装")
        print("  → 程序仍可使用，但图像识别精度可能稍低")
        print("  → 建议安装: pip install opencv-python")
    
    print()
    return True


def test_core_modules():
    """测试核心模块是否能正常导入"""
    print("=" * 60)
    print("测试2: 核心模块导入")
    print("=" * 60)
    
    try:
        from button_locator import ButtonLocator
        print("✓ ButtonLocator 模块导入成功")
    except Exception as e:
        print(f"✗ ButtonLocator 模块导入失败: {e}")
        return False
    
    try:
        from data_loader import DataLoader
        print("✓ DataLoader 模块导入成功")
    except Exception as e:
        print(f"✗ DataLoader 模块导入失败: {e}")
        return False
    
    try:
        from workflow_config import WorkflowConfig
        print("✓ WorkflowConfig 模块导入成功")
    except Exception as e:
        print(f"✗ WorkflowConfig 模块导入失败: {e}")
        return False
    
    try:
        from workflow_executor import WorkflowExecutor
        print("✓ WorkflowExecutor 模块导入成功")
    except Exception as e:
        print(f"✗ WorkflowExecutor 模块导入失败: {e}")
        return False
    
    print()
    return True


def test_module_initialization():
    """测试模块是否能正常初始化"""
    print("=" * 60)
    print("测试3: 模块初始化")
    print("=" * 60)
    
    try:
        from button_locator import ButtonLocator
        locator = ButtonLocator()
        print("✓ ButtonLocator 初始化成功")
        print(f"  → 截图目录: {locator.screenshot_dir}")
    except Exception as e:
        print(f"✗ ButtonLocator 初始化失败: {e}")
        return False
    
    try:
        from data_loader import DataLoader
        loader = DataLoader()
        print("✓ DataLoader 初始化成功")
    except Exception as e:
        print(f"✗ DataLoader 初始化失败: {e}")
        return False
    
    try:
        from workflow_config import WorkflowConfig
        config = WorkflowConfig()
        print("✓ WorkflowConfig 初始化成功")
    except Exception as e:
        print(f"✗ WorkflowConfig 初始化失败: {e}")
        return False
    
    try:
        from workflow_executor import WorkflowExecutor
        from data_loader import DataLoader
        from workflow_config import WorkflowConfig
        
        loader = DataLoader()
        config = WorkflowConfig()
        executor = WorkflowExecutor({}, loader, config)
        print("✓ WorkflowExecutor 初始化成功")
        print(f"  → 搜索范围: {executor.search_range} 像素")
    except Exception as e:
        print(f"✗ WorkflowExecutor 初始化失败: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    print()
    return True


def test_image_recognition():
    """测试图像识别功能"""
    print("=" * 60)
    print("测试4: 图像识别功能")
    print("=" * 60)
    
    try:
        from workflow_executor import WorkflowExecutor
        from data_loader import DataLoader
        from workflow_config import WorkflowConfig
        
        loader = DataLoader()
        config = WorkflowConfig()
        executor = WorkflowExecutor({}, loader, config)
        
        # 测试 _safe_locate_on_screen 方法
        print("✓ WorkflowExecutor._safe_locate_on_screen 方法可用")
        
        # 检查是否有截图文件可以测试
        screenshot_dir = "button_screenshots"
        if os.path.exists(screenshot_dir):
            screenshot_files = [f for f in os.listdir(screenshot_dir) if f.endswith('.png')]
            if screenshot_files:
                print(f"  → 找到 {len(screenshot_files)} 个截图文件")
                print(f"  → 截图文件: {', '.join(screenshot_files[:3])}{'...' if len(screenshot_files) > 3 else ''}")
            else:
                print("  → 截图目录存在但无截图文件")
        else:
            print("  → 截图目录不存在（首次运行时会自动创建）")
        
        # 测试 confidence 参数支持
        try:
            import cv2
            print("  → 支持 confidence 参数（opencv-python 已安装）")
        except ImportError:
            print("  → 不支持 confidence 参数（opencv-python 未安装）")
            print("  → 将使用默认图像识别方式")
        
    except Exception as e:
        print(f"✗ 图像识别功能测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    print()
    return True


def test_config_files():
    """测试配置文件"""
    print("=" * 60)
    print("测试5: 配置文件")
    print("=" * 60)
    
    config_files = {
        "buttons.json": "按钮配置文件",
        "workflow.json": "流程配置文件"
    }
    
    for filename, desc in config_files.items():
        if os.path.exists(filename):
            print(f"✓ {filename} 存在 ({desc})")
            try:
                import json
                with open(filename, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                print(f"  → 文件格式正确，包含 {len(data)} 个项目")
            except Exception as e:
                print(f"  → 文件格式错误: {e}")
        else:
            print(f"⚠ {filename} 不存在 ({desc})")
            print("  → 首次使用时会自动创建")
    
    print()
    return True


def main():
    """主测试函数"""
    print("\n" + "=" * 60)
    print("PyAutoGUI 自动化输入程序 - 功能测试")
    print("=" * 60 + "\n")
    
    results = []
    
    # 执行各项测试
    results.append(("模块导入", test_imports()))
    results.append(("核心模块", test_core_modules()))
    results.append(("模块初始化", test_module_initialization()))
    results.append(("图像识别", test_image_recognition()))
    results.append(("配置文件", test_config_files()))
    
    # 输出测试总结
    print("=" * 60)
    print("测试总结")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✓ 通过" if result else "✗ 失败"
        print(f"{name}: {status}")
    
    print(f"\n总计: {passed}/{total} 项测试通过")
    
    if passed == total:
        print("\n🎉 所有测试通过！程序可以正常使用。")
        print("\n提示: 运行 'python main.py' 启动GUI程序")
    else:
        print("\n⚠️  部分测试失败，请检查错误信息")
    
    print("=" * 60 + "\n")
    
    return passed == total


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

