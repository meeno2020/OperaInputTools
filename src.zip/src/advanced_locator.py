"""
Advanced button matching utilities using template matching (OpenCV + MSS).
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

import cv2
import mss
import numpy as np
import pyautogui


@dataclass
class AdvancedLocatorConfig:
    """Configuration for advanced template matching."""

    template_path: Path
    match_threshold: float = 0.9
    timeout: float = 8.0
    retry_interval: float = 0.3
    search_region: Optional[Tuple[int, int, int, int]] = None  # (left, top, width, height)
    allow_scroll: bool = False
    scroll_step: int = -400
    scroll_pause: float = 0.25
    max_scroll_attempts: int = 6
    screenshot_monitor: int = 0


@dataclass
class MatchResult:
    """Result of template matching."""

    center: Tuple[int, int]
    score: float
    match_count: int


class AdvancedButtonLocator:
    """Locate buttons on screen using template matching with optional scrolling."""

    def __init__(self, config: AdvancedLocatorConfig) -> None:
        self.config = config
        self._validate_config()
        self._mss = mss.mss()
        self._template = self._load_template(config.template_path)
        self._template_height, self._template_width = self._template.shape[:2]

    def _validate_config(self) -> None:
        if not self.config.template_path.exists():
            raise FileNotFoundError(f"Template image not found: {self.config.template_path}")
        if not (0 < self.config.match_threshold <= 1):
            raise ValueError("match_threshold must be in the range (0, 1]")
        if self.config.timeout <= 0:
            raise ValueError("timeout must be greater than 0")

    def _load_template(self, path: Path) -> np.ndarray:
        try:
            data = np.fromfile(str(path), dtype=np.uint8)
            template = cv2.imdecode(data, cv2.IMREAD_COLOR)
        except Exception:  # noqa: BLE001
            template = None
        if template is None:
            raise ValueError(f"Unable to load template image: {path}")
        return template

    def _capture_screen(self) -> Tuple[np.ndarray, Tuple[int, int]]:
        offset = (0, 0)
        if self.config.search_region:
            left, top, width, height = self.config.search_region
            region = {"left": left, "top": top, "width": width, "height": height}
            raw = self._mss.grab(region)
            offset = (left, top)
        else:
            monitor = self._mss.monitors[self.config.screenshot_monitor]
            raw = self._mss.grab(monitor)
            offset = (monitor["left"], monitor["top"])

        frame = np.array(raw)
        frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
        return frame, offset

    def _match_template(self, frame: np.ndarray) -> Tuple[float, Tuple[int, int], int]:
        result = cv2.matchTemplate(frame, self._template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(result)
        match_mask = (result >= self.config.match_threshold).astype(np.uint8)
        num_labels, _ = cv2.connectedComponents(match_mask)
        match_count = max(0, num_labels - 1)
        return max_val, max_loc, match_count

    def locate(self) -> Optional[MatchResult]:
        start_time = time.time()
        scroll_attempts = 0
        last_match_count = 0

        while True:
            elapsed = time.time() - start_time
            if elapsed > self.config.timeout:
                return None

            frame, offset = self._capture_screen()
            score, top_left, match_count = self._match_template(frame)
            last_match_count = match_count

            if score >= self.config.match_threshold:
                x, y = top_left
                center_x = offset[0] + x + self._template_width // 2
                center_y = offset[1] + y + self._template_height // 2
                return MatchResult(center=(center_x, center_y), score=score, match_count=match_count)

            if self.config.allow_scroll and scroll_attempts < self.config.max_scroll_attempts:
                scroll_attempts += 1
                pyautogui.scroll(self.config.scroll_step)
                time.sleep(self.config.scroll_pause)
            else:
                time.sleep(self.config.retry_interval)

    @staticmethod
    def locate_button(
        template_path: Path,
        *,
        match_threshold: float = 0.9,
        timeout: float = 8.0,
        retry_interval: float = 0.3,
        search_region: Optional[Tuple[int, int, int, int]] = None,
        allow_scroll: bool = False,
        scroll_step: int = -400,
        scroll_pause: float = 0.25,
        max_scroll_attempts: int = 6,
        screenshot_monitor: int = 0,
    ) -> Optional[MatchResult]:
        """Convenience wrapper to perform a one-off locate call."""
        config = AdvancedLocatorConfig(
            template_path=Path(template_path),
            match_threshold=match_threshold,
            timeout=timeout,
            retry_interval=retry_interval,
            search_region=search_region,
            allow_scroll=allow_scroll,
            scroll_step=scroll_step,
            scroll_pause=scroll_pause,
            max_scroll_attempts=max_scroll_attempts,
            screenshot_monitor=screenshot_monitor,
        )
        locator = AdvancedButtonLocator(config)
        return locator.locate()
