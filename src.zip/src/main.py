"""
主程序 - Opera Input Tools
整合按钮定位、数据加载、流程配置和执行功能
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
from button_locator import ButtonLocator
from data_loader import DataLoader
from workflow_config import WorkflowConfig
from workflow_executor import WorkflowExecutor
from v5_executor import V5WorkflowExecutor


class AutoInputApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Opera Input Tools")
        self.root.geometry("900x700")
        
        # 初始化模块
        self.button_locator = ButtonLocator(callback=self.on_button_located)
        self.data_loader = DataLoader()
        self.workflow_config = WorkflowConfig()
        self.workflow_executor = None
        self.v5_executor = None
        self.search_range = 100  # 默认搜索范围100像素
        
        # 创建界面
        self.create_widgets()
        
        # 加载已保存的配置
        self.load_saved_configs()
    
    def create_widgets(self):
        """创建界面组件"""
        # 创建标签页
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 标签页1：按钮定位
        self.create_button_locator_tab(notebook)
        
        # 标签页2：数据文件加载
        self.create_data_loader_tab(notebook)
        
        # 标签页3：流程配置
        self.create_workflow_config_tab(notebook)
        
        # 标签页4：执行控制
        self.create_execution_tab(notebook)
        
        # 标签页5：V5 Execution Control
        self.create_v5_execution_tab(notebook)
    
    def create_button_locator_tab(self, notebook):
        """创建按钮定位标签页"""
        frame = ttk.Frame(notebook)
        notebook.add(frame, text="Button Location")
        
        # 按钮数量设置
        ttk.Label(frame, text="Button Count:").grid(row=0, column=0, padx=10, pady=10, sticky=tk.W)
        self.button_count_var = tk.IntVar(value=3)
        spinbox = ttk.Spinbox(frame, from_=1, to=20, textvariable=self.button_count_var, width=10)
        spinbox.grid(row=0, column=1, padx=10, pady=10, sticky=tk.W)
        
        # 控制按钮
        btn_frame = ttk.Frame(frame)
        btn_frame.grid(row=1, column=0, columnspan=2, padx=10, pady=10)
        
        self.start_loc_btn = ttk.Button(btn_frame, text="Start Location", command=self.start_button_location)
        self.start_loc_btn.pack(side=tk.LEFT, padx=5)
        
        self.stop_loc_btn = ttk.Button(btn_frame, text="Stop Location", command=self.stop_button_location, state=tk.DISABLED)
        self.stop_loc_btn.pack(side=tk.LEFT, padx=5)
        
        # 状态显示
        self.loc_status_var = tk.StringVar(value="Not started")
        ttk.Label(frame, textvariable=self.loc_status_var).grid(row=2, column=0, columnspan=2, padx=10, pady=10)
        
        # 已定位按钮列表
        ttk.Label(frame, text="Located Buttons:").grid(row=3, column=0, padx=10, pady=5, sticky=tk.W)
        
        list_frame = ttk.Frame(frame)
        list_frame.grid(row=4, column=0, columnspan=2, padx=10, pady=10, sticky=tk.NSEW)
        
        # 创建Treeview显示按钮列表
        columns = ("Button Name", "X Coordinate", "Y Coordinate", "Screenshot Status")
        self.button_tree = ttk.Treeview(list_frame, columns=columns, show="headings", height=10)
        for col in columns:
            self.button_tree.heading(col, text=col)
            if col == "Button Name":
                self.button_tree.column(col, width=120)
            elif col == "Screenshot Status":
                self.button_tree.column(col, width=100)
            else:
                self.button_tree.column(col, width=100)
        self.button_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.button_tree.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.button_tree.configure(yscrollcommand=scrollbar.set)
        
        # 按钮操作区域
        btn_ops_frame = ttk.Frame(frame)
        btn_ops_frame.grid(row=5, column=0, columnspan=2, padx=10, pady=10)
        
        ttk.Button(btn_ops_frame, text="Rename", command=self.rename_button).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_ops_frame, text="Save Button Config", command=self.save_button_config).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_ops_frame, text="Load Button Config", command=self.load_button_config).pack(side=tk.LEFT, padx=5)
        
        frame.grid_rowconfigure(4, weight=1)
        frame.grid_columnconfigure(0, weight=1)
    
    def create_data_loader_tab(self, notebook):
        """创建数据文件加载标签页"""
        frame = ttk.Frame(notebook)
        notebook.add(frame, text="Data File Loading")
        
        # 文件选择
        file_frame = ttk.Frame(frame)
        file_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Button(file_frame, text="Select File", command=self.load_data_file).pack(side=tk.LEFT, padx=5)
        
        self.file_path_var = tk.StringVar(value="No file selected")
        ttk.Label(file_frame, textvariable=self.file_path_var).pack(side=tk.LEFT, padx=10)
        
        # 数据预览
        ttk.Label(frame, text="Data Preview:").pack(anchor=tk.W, padx=10, pady=5)
        
        preview_frame = ttk.Frame(frame)
        preview_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 创建Treeview显示数据
        self.data_tree = ttk.Treeview(preview_frame, show="headings")
        self.data_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        data_scrollbar = ttk.Scrollbar(preview_frame, orient=tk.VERTICAL, command=self.data_tree.yview)
        data_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.data_tree.configure(yscrollcommand=data_scrollbar.set)
        
        # 列名显示
        ttk.Label(frame, text="Field List:").pack(anchor=tk.W, padx=10, pady=5)
        
        self.columns_var = tk.StringVar(value="")
        ttk.Label(frame, textvariable=self.columns_var, wraplength=800).pack(anchor=tk.W, padx=10, pady=5)
    
    def create_workflow_config_tab(self, notebook):
        """创建流程配置标签页"""
        frame = ttk.Frame(notebook)
        notebook.add(frame, text="Workflow Configuration")
        
        # 左侧：可选操作列表
        left_frame = ttk.LabelFrame(frame, text="Available Actions", padding=10)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, padx=5, pady=5)
        
        # 按钮列表
        ttk.Label(left_frame, text="Buttons:").pack(anchor=tk.W)
        self.button_listbox = tk.Listbox(left_frame, height=4)
        self.button_listbox.pack(fill=tk.X, pady=5)
        self.button_listbox.bind('<Double-Button-1>', lambda e: self.add_selected_step())
        
        # 字段列表
        ttk.Label(left_frame, text="Fields:").pack(anchor=tk.W, pady=(10, 0))
        self.field_listbox = tk.Listbox(left_frame, height=4)
        self.field_listbox.pack(fill=tk.X, pady=5)
        self.field_listbox.bind('<Double-Button-1>', lambda e: self.add_selected_step())
        
        # 键盘操作 - 使用Notebook分类显示
        ttk.Label(left_frame, text="Keyboard Actions (Double-click to add):").pack(anchor=tk.W, pady=(10, 0))
        keyboard_notebook = ttk.Notebook(left_frame)
        keyboard_notebook.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # 存储所有键盘列表的引用
        self.key_listboxes = {}
        
        # 定义按键分类
        key_categories = {
            "Basic": ["TAB", "ENTER", "ESC", "SPACE", "BACKSPACE", "DELETE"],
            "Arrows": ["UP", "DOWN", "LEFT", "RIGHT"],
            "Navigation": ["HOME", "END", "PAGEUP", "PAGEDOWN", "INSERT"],
            "Function": ["F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12"],
            "Numbers": ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
            "Letters": ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", 
                       "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"],
            "Shortcuts": ["Ctrl+C", "Ctrl+V", "Ctrl+A", "Ctrl+X", "Ctrl+Z", "Ctrl+Y", 
                         "Ctrl+F", "Ctrl+S", "Ctrl+N", "Ctrl+O", "Alt+Tab", "Win+D"]
        }
        
        # 创建每个分类的标签页
        for category, keys in key_categories.items():
            category_frame = ttk.Frame(keyboard_notebook)
            keyboard_notebook.add(category_frame, text=category)
            
            # 创建列表
            listbox = tk.Listbox(category_frame, height=8)
            listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            
            # 添加滚动条
            scrollbar = ttk.Scrollbar(category_frame, orient=tk.VERTICAL, command=listbox.yview)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
            listbox.configure(yscrollcommand=scrollbar.set)
            
            # 添加按键到列表
            for key in keys:
                listbox.insert(tk.END, key)
            
            # 绑定双击事件
            listbox.bind('<Double-Button-1>', lambda e, lb=listbox: self.add_key_from_listbox(lb))
            
            # 保存引用
            self.key_listboxes[category] = listbox
        
        # 为了兼容性，保留原来的key_listbox引用（指向Basic分类）
        self.key_listbox = self.key_listboxes["Basic"]
        
        # 延迟设置
        delay_frame = ttk.Frame(left_frame)
        delay_frame.pack(fill=tk.X, pady=10)
        ttk.Label(delay_frame, text="Delay (seconds):").pack(side=tk.LEFT)
        self.delay_var = tk.StringVar(value="1")
        ttk.Entry(delay_frame, textvariable=self.delay_var, width=10).pack(side=tk.LEFT, padx=5)
        ttk.Button(delay_frame, text="Add Delay", command=self.add_delay_step).pack(side=tk.LEFT, padx=5)
        
        # 添加步骤按钮
        ttk.Button(left_frame, text="Add Selected", command=self.add_selected_step).pack(pady=10)
        
        # 右侧：流程步骤列表
        right_frame = ttk.LabelFrame(frame, text="Workflow Steps", padding=10)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 流程步骤列表（支持拖拽）
        steps_frame = ttk.Frame(right_frame)
        steps_frame.pack(fill=tk.BOTH, expand=True)
        
        self.workflow_listbox = tk.Listbox(steps_frame, height=15)
        self.workflow_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        workflow_scrollbar = ttk.Scrollbar(steps_frame, orient=tk.VERTICAL, command=self.workflow_listbox.yview)
        workflow_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.workflow_listbox.configure(yscrollcommand=workflow_scrollbar.set)
        
        # 绑定拖拽事件
        self.workflow_listbox.bind('<Button-1>', self.on_drag_start)
        self.workflow_listbox.bind('<B1-Motion>', self.on_drag_motion)
        self.workflow_listbox.bind('<ButtonRelease-1>', self.on_drag_end)
        
        # 流程操作按钮
        btn_frame = ttk.Frame(right_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(btn_frame, text="Delete Selected", command=self.remove_selected_step).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Move Up", command=self.move_step_up).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Move Down", command=self.move_step_down).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Clear", command=self.clear_workflow).pack(side=tk.LEFT, padx=5)
        
        # 保存/加载按钮
        save_frame = ttk.Frame(right_frame)
        save_frame.pack(fill=tk.X)
        
        ttk.Button(save_frame, text="Save Workflow", command=self.save_workflow).pack(side=tk.LEFT, padx=5)
        ttk.Button(save_frame, text="Load Workflow", command=self.load_workflow).pack(side=tk.LEFT, padx=5)
        
        # 拖拽相关变量
        self.drag_start_index = None
    
    def create_execution_tab(self, notebook):
        """创建执行控制标签页"""
        frame = ttk.Frame(notebook)
        notebook.add(frame, text="Execution Control")
        
        # 设置区域（使用Grid布局，支持自动换行）
        settings_frame = ttk.LabelFrame(frame, text="Settings", padding=10)
        settings_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # 第一行：按钮搜索范围
        row = 0
        ttk.Label(settings_frame, text="Button Search Range (pixels):").grid(row=row, column=0, sticky=tk.W, padx=5, pady=5)
        self.search_range_var = tk.IntVar(value=200)
        search_range_spinbox = ttk.Spinbox(settings_frame, from_=50, to=1000, textvariable=self.search_range_var, width=10)
        search_range_spinbox.grid(row=row, column=1, sticky=tk.W, padx=5, pady=5)
        ttk.Label(settings_frame, text="(Recommended: 200-300 pixels, top search range auto-expands 2x)").grid(row=row, column=2, sticky=tk.W, padx=5, pady=5)
        
        # 第二行：显示点击位置选项
        row += 1
        self.show_click_position_var = tk.BooleanVar(value=False)
        show_click_check = ttk.Checkbutton(settings_frame, text="Show Mouse Click Position", variable=self.show_click_position_var)
        show_click_check.grid(row=row, column=0, columnspan=2, sticky=tk.W, padx=5, pady=5)
        
        # 第三行：播放提示音选项
        row += 1
        self.play_sound_var = tk.BooleanVar(value=True)
        play_sound_check = ttk.Checkbutton(settings_frame, text="Play Sound After Each Row", variable=self.play_sound_var)
        play_sound_check.grid(row=row, column=0, columnspan=2, sticky=tk.W, padx=5, pady=5)
        
        # 第四行：开始行数设置
        row += 1
        ttk.Label(settings_frame, text="Start Row:").grid(row=row, column=0, sticky=tk.W, padx=5, pady=5)
        self.start_row_var = tk.IntVar(value=1)
        self.start_row_spinbox = ttk.Spinbox(settings_frame, from_=1, to=10000, textvariable=self.start_row_var, width=8)
        self.start_row_spinbox.grid(row=row, column=1, sticky=tk.W, padx=5, pady=5)
        ttk.Label(settings_frame, text="(Row number to start execution)").grid(row=row, column=2, sticky=tk.W, padx=5, pady=5)
        
        # 配置列权重，使布局能够自适应
        settings_frame.columnconfigure(0, weight=0)
        settings_frame.columnconfigure(1, weight=0)
        settings_frame.columnconfigure(2, weight=1)
        
        # 控制按钮
        btn_frame = ttk.Frame(frame)
        btn_frame.pack(pady=20)
        
        self.start_exec_btn = ttk.Button(btn_frame, text="Start Execution", command=self.start_execution, width=15)
        self.start_exec_btn.pack(side=tk.LEFT, padx=10)
        
        self.pause_exec_btn = ttk.Button(btn_frame, text="Pause", command=self.pause_execution, width=15, state=tk.DISABLED)
        self.pause_exec_btn.pack(side=tk.LEFT, padx=10)
        
        self.stop_exec_btn = ttk.Button(btn_frame, text="Stop", command=self.stop_execution, width=15, state=tk.DISABLED)
        self.stop_exec_btn.pack(side=tk.LEFT, padx=10)
        
        self.restart_exec_btn = ttk.Button(btn_frame, text="Restart", command=self.restart_execution, width=15, state=tk.DISABLED)
        self.restart_exec_btn.pack(side=tk.LEFT, padx=10)
        
        # 状态显示
        status_frame = ttk.LabelFrame(frame, text="Execution Status", padding=10)
        status_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.exec_status_var = tk.StringVar(value="Ready")
        ttk.Label(status_frame, textvariable=self.exec_status_var, font=("Arial", 12)).pack()
        
        # 进度条
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(status_frame, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(fill=tk.X, pady=10)
        
        self.progress_text_var = tk.StringVar(value="0 / 0")
        ttk.Label(status_frame, textvariable=self.progress_text_var).pack()
        
        # 执行日志
        log_frame = ttk.LabelFrame(frame, text="Execution Log", padding=10)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        log_scroll = ttk.Scrollbar(log_frame)
        log_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.log_text = tk.Text(log_frame, height=15, yscrollcommand=log_scroll.set)
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        log_scroll.config(command=self.log_text.yview)
    
    def create_v5_execution_tab(self, notebook):
        """Create V5 Execution Control tab"""
        frame = ttk.Frame(notebook)
        notebook.add(frame, text="V5 Execution Control")
        
        # Settings area
        settings_frame = ttk.LabelFrame(frame, text="Settings", padding=10)
        settings_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # First row: Delay after each field input
        row = 0
        ttk.Label(settings_frame, text="Delay After Each Field (seconds):").grid(row=row, column=0, sticky=tk.W, padx=5, pady=5)
        self.v5_delay_var = tk.DoubleVar(value=1.0)
        delay_spinbox = ttk.Spinbox(settings_frame, from_=0.1, to=10.0, increment=0.1, textvariable=self.v5_delay_var, width=10)
        delay_spinbox.grid(row=row, column=1, sticky=tk.W, padx=5, pady=5)
        ttk.Label(settings_frame, text="(Delay after each field input, before pressing Enter)").grid(row=row, column=2, sticky=tk.W, padx=5, pady=5)
        
        # Second row: Start row number
        row += 1
        ttk.Label(settings_frame, text="Start Row:").grid(row=row, column=0, sticky=tk.W, padx=5, pady=5)
        self.v5_start_row_var = tk.IntVar(value=1)
        self.v5_start_row_spinbox = ttk.Spinbox(settings_frame, from_=1, to=10000, textvariable=self.v5_start_row_var, width=8)
        self.v5_start_row_spinbox.grid(row=row, column=1, sticky=tk.W, padx=5, pady=5)
        ttk.Label(settings_frame, text="(Row number to start execution)").grid(row=row, column=2, sticky=tk.W, padx=5, pady=5)
        
        # Third row: Play sound option
        row += 1
        self.v5_play_sound_var = tk.BooleanVar(value=True)
        play_sound_check = ttk.Checkbutton(settings_frame, text="Play Sound After Each Row", variable=self.v5_play_sound_var)
        play_sound_check.grid(row=row, column=0, columnspan=2, sticky=tk.W, padx=5, pady=5)
        
        # Configure column weights
        settings_frame.columnconfigure(0, weight=0)
        settings_frame.columnconfigure(1, weight=0)
        settings_frame.columnconfigure(2, weight=1)
        
        # Control buttons
        btn_frame = ttk.Frame(frame)
        btn_frame.pack(pady=20)
        
        self.v5_start_btn = ttk.Button(btn_frame, text="Start", command=self.start_v5_execution, width=15)
        self.v5_start_btn.pack(side=tk.LEFT, padx=10)
        
        self.v5_stop_btn = ttk.Button(btn_frame, text="Stop", command=self.stop_v5_execution, width=15, state=tk.DISABLED)
        self.v5_stop_btn.pack(side=tk.LEFT, padx=10)
        
        # Status display
        status_frame = ttk.LabelFrame(frame, text="Execution Status", padding=10)
        status_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.v5_exec_status_var = tk.StringVar(value="Ready")
        ttk.Label(status_frame, textvariable=self.v5_exec_status_var, font=("Arial", 12)).pack()
        
        # Progress bar
        self.v5_progress_var = tk.DoubleVar()
        self.v5_progress_bar = ttk.Progressbar(status_frame, variable=self.v5_progress_var, maximum=100)
        self.v5_progress_bar.pack(fill=tk.X, pady=10)
        
        self.v5_progress_text_var = tk.StringVar(value="0 / 0")
        ttk.Label(status_frame, textvariable=self.v5_progress_text_var).pack()
        
        # Execution log
        log_frame = ttk.LabelFrame(frame, text="Execution Log", padding=10)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        log_scroll = ttk.Scrollbar(log_frame)
        log_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.v5_log_text = tk.Text(log_frame, height=15, yscrollcommand=log_scroll.set)
        self.v5_log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        log_scroll.config(command=self.v5_log_text.yview)
    
    # 按钮定位相关方法
    def start_button_location(self):
        """开始按钮定位"""
        button_count = self.button_count_var.get()
        if button_count <= 0:
            messagebox.showwarning("Warning", "Button count must be greater than 0")
            return
        
        if self.button_locator.start_listening(button_count):
            self.start_loc_btn.config(state=tk.DISABLED)
            self.stop_loc_btn.config(state=tk.NORMAL)
            self.loc_status_var.set(f"Location Mode: Move mouse to target position, press Shift+W to confirm (0/{button_count})")
            # 清空按钮列表
            for item in self.button_tree.get_children():
                self.button_tree.delete(item)
        else:
            messagebox.showerror("Error", "Failed to start location")
    
    def stop_button_location(self):
        """停止按钮定位"""
        self.button_locator.stop_listening()
        self.start_loc_btn.config(state=tk.NORMAL)
        self.stop_loc_btn.config(state=tk.DISABLED)
        
        # 保存按钮坐标
        if self.button_locator.save_buttons():
            self.loc_status_var.set("Location finished, coordinates saved")
        else:
            self.loc_status_var.set("Location finished, but save failed")
        
        # 更新按钮列表显示
        self.update_button_list()
    
    def on_button_located(self, button_name, x, y, image_path=None, error_msg=None):
        """按钮定位回调"""
        current, total = self.button_locator.get_progress()
        status_text = f"Location Mode: Located {current}/{total} buttons"
        if error_msg:
            status_text += f" (Warning: {error_msg})"
        self.loc_status_var.set(status_text)
        
        # 添加到列表
        if image_path:
            self.button_tree.insert("", tk.END, values=(button_name, x, y, "Screenshot OK"))
        else:
            status = "Coordinates Only"
            if error_msg:
                status = f"Screenshot Failed: {error_msg[:20]}..." if len(error_msg) > 20 else f"Screenshot Failed: {error_msg}"
            self.button_tree.insert("", tk.END, values=(button_name, x, y, status))
        
        # 更新流程配置中的按钮列表
        self.update_button_list_in_config()
        
        # 如果全部定位完成，自动停止
        if self.button_locator.is_complete():
            self.stop_button_location()
    
    def update_button_list(self):
        """更新按钮列表显示"""
        buttons = self.button_locator.get_buttons()
        for item in self.button_tree.get_children():
            self.button_tree.delete(item)
        for name, button_data in buttons.items():
            x = button_data.get("x", 0)
            y = button_data.get("y", 0)
            if "image_path" in button_data and button_data.get("image_path"):
                status = "Screenshot OK"
            else:
                status = "Coordinates Only"
            self.button_tree.insert("", tk.END, values=(name, x, y, status))
    
    def update_button_list_in_config(self):
        """更新流程配置中的按钮列表"""
        buttons = self.button_locator.get_buttons()
        self.button_listbox.delete(0, tk.END)
        for name in sorted(buttons.keys()):
            self.button_listbox.insert(tk.END, name)
    
    def rename_button(self):
        """改名选中的按钮"""
        selection = self.button_tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a button first")
            return
        
        # 获取选中的按钮信息
        item = self.button_tree.item(selection[0])
        old_name = item['values'][0] if item['values'] else None
        if not old_name:
            return
        
        # 弹出输入对话框
        dialog = tk.Toplevel(self.root)
        dialog.title("Rename Button")
        dialog.geometry("300x120")
        dialog.transient(self.root)
        dialog.grab_set()
        
        ttk.Label(dialog, text=f"Old Name: {old_name}").pack(pady=10)
        ttk.Label(dialog, text="New Name:").pack()
        
        new_name_var = tk.StringVar(value=old_name)
        entry = ttk.Entry(dialog, textvariable=new_name_var, width=20)
        entry.pack(pady=5)
        entry.select_range(0, tk.END)
        entry.focus()
        
        def confirm_rename():
            new_name = new_name_var.get().strip()
            if not new_name:
                messagebox.showwarning("Warning", "Button name cannot be empty")
                return
            
            if new_name == old_name:
                dialog.destroy()
                return
            
            # 执行改名
            if self.button_locator.rename_button(old_name, new_name):
                # 更新显示
                self.update_button_list()
                self.update_button_list_in_config()
                # 更新流程配置中的按钮引用（如果流程中使用了该按钮）
                self.update_workflow_after_button_rename(old_name, new_name)
                dialog.destroy()
                messagebox.showinfo("Success", f"Button renamed to: {new_name}")
            else:
                messagebox.showerror("Error", "Rename failed, new name may already exist")
        
        btn_frame = ttk.Frame(dialog)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="OK", command=confirm_rename).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Cancel", command=dialog.destroy).pack(side=tk.LEFT, padx=5)
        
        # 绑定回车键
        entry.bind('<Return>', lambda e: confirm_rename())
    
    def save_button_config(self):
        """保存按钮配置到文件"""
        filepath = filedialog.asksaveasfilename(
            title="Save Button Configuration",
            defaultextension=".json",
            filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")]
        )
        
        if filepath:
            if self.button_locator.save_buttons(filepath):
                messagebox.showinfo("Success", "Button configuration saved")
            else:
                messagebox.showerror("Error", "Save failed")
    
    def load_button_config(self):
        """从文件加载按钮配置"""
        filepath = filedialog.askopenfilename(
            title="Load Button Configuration",
            filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")]
        )
        
        if filepath:
            if self.button_locator.load_buttons(filepath):
                # 更新显示
                self.update_button_list()
                self.update_button_list_in_config()
                messagebox.showinfo("Success", "Button configuration loaded")
            else:
                messagebox.showerror("Error", "Load failed")
    
    def update_workflow_after_button_rename(self, old_name, new_name):
        """按钮改名后更新流程配置中的按钮引用"""
        steps = self.workflow_config.get_steps()
        updated = False
        for step in steps:
            if step.get("type") == "button" and step.get("name") == old_name:
                step["name"] = new_name
                updated = True
        
        if updated:
            self.update_workflow_list()
    
    # 数据加载相关方法
    def load_data_file(self):
        """加载数据文件"""
        filepath = filedialog.askopenfilename(
            title="Select Data File",
            filetypes=[("CSV Files", "*.csv"), ("Excel Files", "*.xlsx *.xls"), ("All Files", "*.*")]
        )
        
        if filepath:
            if self.data_loader.load_file(filepath):
                self.file_path_var.set(filepath)
                self.update_data_preview()
                self.update_field_list()
                # 更新开始行数的最大值
                total_rows = self.data_loader.get_row_count()
                if total_rows > 0:
                    # 更新spinbox的最大值
                    self.start_row_spinbox.config(to=total_rows)
                    # 如果开始行数超过总行数，重置为1
                    if self.start_row_var.get() > total_rows:
                        self.start_row_var.set(1)
                    # 更新V5执行控制的开始行数最大值
                    if hasattr(self, 'v5_start_row_spinbox'):
                        self.v5_start_row_spinbox.config(to=total_rows)
                        if self.v5_start_row_var.get() > total_rows:
                            self.v5_start_row_var.set(1)
                messagebox.showinfo("Success", f"Data file loaded successfully ({total_rows} rows)")
            else:
                messagebox.showerror("Error", "Data file loading failed")
    
    def update_data_preview(self):
        """更新数据预览"""
        # 清空现有数据
        for item in self.data_tree.get_children():
            self.data_tree.delete(item)
        
        # 清空列
        self.data_tree["columns"] = ()
        
        if not self.data_loader.is_loaded():
            return
        
        # 获取列名
        columns = self.data_loader.get_columns()
        self.data_tree["columns"] = columns
        
        for col in columns:
            self.data_tree.heading(col, text=col)
            self.data_tree.column(col, width=100)
        
        # 添加数据
        preview_data = self.data_loader.preview_data(20)
        for _, row in preview_data.iterrows():
            values = [str(row[col]) for col in columns]
            self.data_tree.insert("", tk.END, values=values)
    
    def update_field_list(self):
        """更新字段列表"""
        self.field_listbox.delete(0, tk.END)
        if self.data_loader.is_loaded():
            columns = self.data_loader.get_columns()
            for col in columns:
                self.field_listbox.insert(tk.END, col)
    
    # 流程配置相关方法
    def add_key_from_listbox(self, listbox):
        """从键盘列表添加按键（双击事件）"""
        selection = listbox.curselection()
        if selection:
            key_name = listbox.get(selection[0])
            self.workflow_config.add_step("key", key_name)
            self.update_workflow_list()
    
    def add_selected_step(self):
        """添加选中的步骤"""
        # 检查按钮列表
        if self.button_listbox.curselection():
            button_name = self.button_listbox.get(self.button_listbox.curselection()[0])
            self.workflow_config.add_step("button", button_name)
            self.update_workflow_list()
            return
        
        # 检查字段列表
        if self.field_listbox.curselection():
            field_name = self.field_listbox.get(self.field_listbox.curselection()[0])
            self.workflow_config.add_step("field", field_name)
            self.update_workflow_list()
            return
        
        # 检查所有键盘操作列表（包括所有分类）
        if hasattr(self, 'key_listboxes'):
            for category, listbox in self.key_listboxes.items():
                if listbox.curselection():
                    key_name = listbox.get(listbox.curselection()[0])
                    self.workflow_config.add_step("key", key_name)
                    self.update_workflow_list()
                    return
        # 兼容旧代码：检查原来的key_listbox
        elif hasattr(self, 'key_listbox') and self.key_listbox.curselection():
            key_name = self.key_listbox.get(self.key_listbox.curselection()[0])
            self.workflow_config.add_step("key", key_name)
            self.update_workflow_list()
            return
    
    def add_delay_step(self):
        """添加延迟步骤"""
        try:
            seconds = float(self.delay_var.get())
            self.workflow_config.add_step("delay", seconds=seconds)
            self.update_workflow_list()
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number")
    
    def remove_selected_step(self):
        """删除选中的步骤"""
        selection = self.workflow_listbox.curselection()
        if selection:
            index = selection[0]
            self.workflow_config.remove_step(index)
            self.update_workflow_list()
    
    def move_step_up(self):
        """上移步骤"""
        selection = self.workflow_listbox.curselection()
        if selection and selection[0] > 0:
            index = selection[0]
            self.workflow_config.move_step(index, index - 1)
            self.update_workflow_list()
            self.workflow_listbox.selection_set(index - 1)
    
    def move_step_down(self):
        """下移步骤"""
        selection = self.workflow_listbox.curselection()
        if selection:
            index = selection[0]
            if index < len(self.workflow_config.get_steps()) - 1:
                self.workflow_config.move_step(index, index + 1)
                self.update_workflow_list()
                self.workflow_listbox.selection_set(index + 1)
    
    def clear_workflow(self):
        """清空流程"""
        if messagebox.askyesno("Confirm", "Are you sure you want to clear all workflow steps?"):
            self.workflow_config.clear_steps()
            self.update_workflow_list()
    
    def update_workflow_list(self):
        """更新流程列表显示"""
        # 清空现有列表
        self.workflow_listbox.delete(0, tk.END)
        
        # 获取步骤
        steps = self.workflow_config.get_steps()
        
        # 添加步骤到列表
        for step in steps:
            step_type = step.get("type")
            if step_type == "button":
                self.workflow_listbox.insert(tk.END, f"Click {step.get('name')}")
            elif step_type == "field":
                self.workflow_listbox.insert(tk.END, f"Input Field {step.get('name')}")
            elif step_type == "key":
                self.workflow_listbox.insert(tk.END, f"Press Key {step.get('name')}")
            elif step_type == "delay":
                self.workflow_listbox.insert(tk.END, f"Delay {step.get('seconds')} seconds")
        
        # 强制刷新界面以确保显示更新
        self.workflow_listbox.update_idletasks()
    
    def save_workflow(self):
        """保存流程"""
        filepath = filedialog.asksaveasfilename(
            title="Save Workflow Configuration",
            defaultextension=".json",
            filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")]
        )
        
        if filepath:
            if self.workflow_config.save_workflow(filepath):
                messagebox.showinfo("Success", "Workflow configuration saved")
            else:
                messagebox.showerror("Error", "Save failed")
    
    def load_workflow(self):
        """加载流程"""
        filepath = filedialog.askopenfilename(
            title="Load Workflow Configuration",
            filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")]
        )
        
        if filepath:
            if self.workflow_config.load_workflow(filepath):
                # 更新流程列表显示
                self.update_workflow_list()
                # 强制刷新界面
                self.root.update_idletasks()
                messagebox.showinfo("Success", f"Workflow configuration loaded\nTotal {len(self.workflow_config.get_steps())} steps")
            else:
                messagebox.showerror("Error", "Load failed, please check file format")
    
    # 拖拽功能
    def on_drag_start(self, event):
        """拖拽开始"""
        widget = event.widget
        index = widget.nearest(event.y)
        if index >= 0:
            self.drag_start_index = index
    
    def on_drag_motion(self, event):
        """拖拽移动"""
        pass
    
    def on_drag_end(self, event):
        """拖拽结束"""
        if self.drag_start_index is None:
            return
        
        widget = event.widget
        index = widget.nearest(event.y)
        
        if index >= 0 and index != self.drag_start_index:
            self.workflow_config.move_step(self.drag_start_index, index)
            self.update_workflow_list()
            widget.selection_set(index)
        
        self.drag_start_index = None
    
    # 执行相关方法
    def start_execution(self):
        """开始执行"""
        buttons = self.button_locator.get_buttons()
        if len(buttons) == 0:
            messagebox.showwarning("Warning", "Please locate buttons first")
            return
        
        if not self.data_loader.is_loaded():
            messagebox.showwarning("Warning", "Please load data file first")
            return
        
        if len(self.workflow_config.get_steps()) == 0:
            messagebox.showwarning("Warning", "Please configure workflow first")
            return
        
        # 获取搜索范围设置
        self.search_range = self.search_range_var.get()
        
        # 获取显示点击位置设置
        show_click_position = self.show_click_position_var.get()
        
        # 获取播放提示音设置
        play_sound = self.play_sound_var.get()
        
        # 获取开始行数设置（转换为从0开始的索引）
        start_row_input = self.start_row_var.get()
        total_rows = self.data_loader.get_row_count()
        if start_row_input < 1 or start_row_input > total_rows:
            messagebox.showwarning("Warning", f"Invalid start row (should be between 1-{total_rows})")
            return
        start_row_index = start_row_input - 1  # 转换为从0开始的索引
        
        # 创建执行器（使用自定义搜索范围和点击位置显示选项）
        self.workflow_executor = WorkflowExecutor(
            buttons, self.data_loader, self.workflow_config,
            callback=self.on_execution_progress,
            search_range=self.search_range,
            show_click_position=show_click_position,
            play_sound=play_sound
        )
        
        # 更新UI状态
        self.start_exec_btn.config(state=tk.DISABLED)
        self.pause_exec_btn.config(state=tk.NORMAL)
        self.stop_exec_btn.config(state=tk.NORMAL)
        self.restart_exec_btn.config(state=tk.DISABLED)
        self.exec_status_var.set("Preparing to start...")
        self.log_text.delete(1.0, tk.END)
        self.log_text.insert(tk.END, "Preparing to start execution...\n")
        self.root.update_idletasks()
        
        # 在后台线程中等待3秒，给用户定位鼠标的时间
        def start_after_delay():
            import time
            for i in range(3, 0, -1):
                if not self.workflow_executor or not hasattr(self, 'exec_status_var'):
                    return
                self.exec_status_var.set(f"Starting in {i} seconds...")
                self.on_execution_progress(0, 0, f"Starting in {i} seconds... Please position your mouse.")
                time.sleep(1)
            
            # 3秒后开始执行
            if self.workflow_executor and self.workflow_executor.start(start_row_index):
                self.exec_status_var.set("Executing...")
                self.on_execution_progress(0, 0, "Execution started!")
            else:
                # 如果启动失败，恢复按钮状态
                self.start_exec_btn.config(state=tk.NORMAL)
                self.pause_exec_btn.config(state=tk.DISABLED)
                self.stop_exec_btn.config(state=tk.DISABLED)
                self.restart_exec_btn.config(state=tk.DISABLED)
                self.exec_status_var.set("Ready")
        
        # 在后台线程中执行延迟
        delay_thread = threading.Thread(target=start_after_delay, daemon=True)
        delay_thread.start()
    
    def pause_execution(self):
        """暂停/继续执行"""
        if self.workflow_executor:
            if self.workflow_executor.is_paused_state():
                self.workflow_executor.resume()
                self.pause_exec_btn.config(text="Pause")
                self.exec_status_var.set("Executing...")
            else:
                self.workflow_executor.pause()
                self.pause_exec_btn.config(text="Resume")
                self.exec_status_var.set("Paused")
    
    def stop_execution(self):
        """停止执行"""
        if self.workflow_executor:
            self.workflow_executor.stop()
            self.start_exec_btn.config(state=tk.NORMAL)
            self.pause_exec_btn.config(state=tk.DISABLED, text="Pause")
            self.stop_exec_btn.config(state=tk.DISABLED)
            self.restart_exec_btn.config(state=tk.NORMAL)
            self.exec_status_var.set("Stopped")
    
    def restart_execution(self):
        """重新开始执行"""
        # 先停止当前执行（如果正在执行）
        if self.workflow_executor and self.workflow_executor.is_executing():
            self.workflow_executor.stop()
            # 等待停止完成
            import time
            time.sleep(0.2)
        
        # 重置进度和日志
        self.progress_var.set(0)
        self.progress_text_var.set("0 / 0")
        self.log_text.delete(1.0, tk.END)
        self.exec_status_var.set("Ready to restart...")
        
        # 重新开始执行
        self.start_execution()
    
    def on_execution_progress(self, current_row, total_rows, message):
        """执行进度回调"""
        # 检查是否是点击位置显示消息
        if message.startswith("__CLICK_POS__:"):
            # 解析点击位置信息
            parts = message.split(":")
            if len(parts) >= 4:
                button_name = parts[1]
                x = int(parts[2])
                y = int(parts[3])
                self._show_click_position_tooltip(x, y, button_name)
            return
        
        if total_rows > 0:
            progress = (current_row / total_rows) * 100
            self.progress_var.set(progress)
            self.progress_text_var.set(f"{current_row} / {total_rows}")
        
        self.log_text.insert(tk.END, f"{message}\n")
        self.log_text.see(tk.END)
        
        # 如果执行完成
        if current_row >= total_rows and total_rows > 0:
            self.start_exec_btn.config(state=tk.NORMAL)
            self.pause_exec_btn.config(state=tk.DISABLED, text="Pause")
            self.stop_exec_btn.config(state=tk.DISABLED)
            self.restart_exec_btn.config(state=tk.NORMAL)
    
    # V5 Execution Control methods
    def start_v5_execution(self):
        """Start V5 execution"""
        if not self.data_loader.is_loaded():
            messagebox.showwarning("Warning", "Please load data file first")
            return
        
        # Get delay setting
        delay_seconds = self.v5_delay_var.get()
        
        # Get play sound setting
        play_sound = self.v5_play_sound_var.get()
        
        # Get start row number (convert to 0-based index)
        start_row_input = self.v5_start_row_var.get()
        total_rows = self.data_loader.get_row_count()
        if start_row_input < 1 or start_row_input > total_rows:
            messagebox.showwarning("Warning", f"Invalid start row (should be between 1-{total_rows})")
            return
        start_row_index = start_row_input - 1  # Convert to 0-based index
        
        # Create V5 executor
        self.v5_executor = V5WorkflowExecutor(
            self.data_loader,
            callback=self.on_v5_execution_progress,
            delay_seconds=delay_seconds,
            play_sound=play_sound
        )
        
        # Update UI state
        self.v5_start_btn.config(state=tk.DISABLED)
        self.v5_stop_btn.config(state=tk.NORMAL)
        self.v5_exec_status_var.set("Preparing to start...")
        self.v5_log_text.delete(1.0, tk.END)
        self.v5_log_text.insert(tk.END, "Preparing to start V5 execution...\n")
        self.root.update_idletasks()
        
        # Wait 3 seconds in background thread to give user time to position mouse
        def start_v5_after_delay():
            import time
            for i in range(3, 0, -1):
                if not self.v5_executor or not hasattr(self, 'v5_exec_status_var'):
                    return
                self.v5_exec_status_var.set(f"Starting in {i} seconds...")
                self.on_v5_execution_progress(0, 0, f"Starting in {i} seconds... Please position your mouse.")
                time.sleep(1)
            
            # Start execution after 3 seconds
            if self.v5_executor and self.v5_executor.start(start_row_index):
                self.v5_exec_status_var.set("Executing...")
                self.on_v5_execution_progress(0, 0, "V5 execution started!")
            else:
                # If start failed, restore button state
                self.v5_start_btn.config(state=tk.NORMAL)
                self.v5_stop_btn.config(state=tk.DISABLED)
                self.v5_exec_status_var.set("Ready")
        
        # Execute delay in background thread
        delay_thread = threading.Thread(target=start_v5_after_delay, daemon=True)
        delay_thread.start()
    
    def stop_v5_execution(self):
        """Stop V5 execution"""
        if self.v5_executor:
            self.v5_executor.stop()
            self.v5_start_btn.config(state=tk.NORMAL)
            self.v5_stop_btn.config(state=tk.DISABLED)
            self.v5_exec_status_var.set("Stopped")
    
    def on_v5_execution_progress(self, current_row, total_rows, message):
        """V5 execution progress callback"""
        if total_rows > 0:
            progress = (current_row / total_rows) * 100
            self.v5_progress_var.set(progress)
            self.v5_progress_text_var.set(f"{current_row} / {total_rows}")
        
        self.v5_log_text.insert(tk.END, f"{message}\n")
        self.v5_log_text.see(tk.END)
        
        # If execution completed
        if current_row >= total_rows and total_rows > 0:
            self.v5_start_btn.config(state=tk.NORMAL)
            self.v5_stop_btn.config(state=tk.DISABLED)
            self.v5_exec_status_var.set("Completed")
    
    def _show_click_position_tooltip(self, x, y, button_name=""):
        """
        显示鼠标点击位置提示窗口
        :param x: X坐标
        :param y: Y坐标
        :param button_name: 按钮名称
        """
        try:
            # 创建提示窗口
            tooltip = tk.Toplevel(self.root)
            tooltip.overrideredirect(True)  # 无边框
            tooltip.attributes('-topmost', True)  # 置顶
            tooltip.attributes('-alpha', 0.85)  # 半透明
            
            # 设置窗口位置（在点击位置附近）
            window_width = 200
            window_height = 70
            window_x = x - window_width // 2
            window_y = y - window_height - 40  # 显示在点击位置上方
            
            # 确保窗口在屏幕内
            screen_width = self.root.winfo_screenwidth()
            screen_height = self.root.winfo_screenheight()
            window_x = max(10, min(window_x, screen_width - window_width - 10))
            window_y = max(10, min(window_y, screen_height - window_height - 10))
            
            tooltip.geometry(f"{window_width}x{window_height}+{window_x}+{window_y}")
            
            # 创建标签显示信息
            info_text = f"Click Position:\n({x}, {y})"
            if button_name:
                info_text = f"{button_name}\n{info_text}"
            
            label = tk.Label(
                tooltip,
                text=info_text,
                bg='yellow',
                fg='black',
                font=('Arial', 9, 'bold'),
                padx=10,
                pady=5,
                justify=tk.CENTER
            )
            label.pack(fill=tk.BOTH, expand=True)
            
            # 0.8秒后自动关闭
            def close_tooltip():
                try:
                    tooltip.destroy()
                except:
                    pass
            
            tooltip.after(800, close_tooltip)
        except Exception:
            # 如果显示失败，忽略（不影响主流程）
            pass
    
    def load_saved_configs(self):
        """加载已保存的配置"""
        # 加载按钮坐标
        self.button_locator.load_buttons()
        self.update_button_list()
        self.update_button_list_in_config()
        
        # 自动加载流程配置（如果存在默认的 workflow.json）
        import os
        default_workflow_path = "workflow.json"
        if os.path.exists(default_workflow_path):
            if self.workflow_config.load_workflow(default_workflow_path):
                self.update_workflow_list()
                # 静默加载，不显示提示框
    
    def on_closing(self):
        """窗口关闭事件"""
        # 停止定位
        if self.button_locator.is_listening:
            self.button_locator.stop_listening()
        
        # 停止执行
        if self.workflow_executor and self.workflow_executor.is_executing():
            self.workflow_executor.stop()
        
        # 停止V5执行
        if self.v5_executor and self.v5_executor.is_executing():
            self.v5_executor.stop()
        
        self.root.destroy()


def main():
    root = tk.Tk()
    app = AutoInputApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()


if __name__ == "__main__":
    main()

