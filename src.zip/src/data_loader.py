"""
数据加载模块
负责加载CSV和Excel文件
"""
import pandas as pd
import os


class DataLoader:
    def __init__(self):
        self.data = None
        self.columns = []
        self.filepath = None
        
    def load_file(self, filepath):
        """
        加载数据文件（支持CSV和Excel）
        :param filepath: 文件路径
        :return: 是否加载成功
        """
        try:
            if not os.path.exists(filepath):
                return False
            
            self.filepath = filepath
            file_ext = os.path.splitext(filepath)[1].lower()
            
            if file_ext == '.csv':
                # 读取CSV文件，强制使用字符串类型，避免自动转换导致的小数点等问题
                self.data = pd.read_csv(
                    filepath,
                    encoding='utf-8',
                    dtype=str,
                    keep_default_na=False,
                )
            elif file_ext in ['.xlsx', '.xls']:
                # 读取Excel文件，同样强制所有列为字符串
                self.data = pd.read_excel(
                    filepath,
                    dtype=str,
                    keep_default_na=False,
                )
            else:
                return False
            
            # 获取列名
            self.columns = list(self.data.columns)
            return True
            
        except Exception as e:
            print(f"加载数据文件失败: {e}")
            return False
    
    def get_columns(self):
        """获取列名列表"""
        return self.columns.copy()
    
    def get_data(self):
        """获取数据DataFrame"""
        return self.data
    
    def get_row_count(self):
        """获取数据行数"""
        if self.data is not None:
            return len(self.data)
        return 0
    
    def get_row(self, index):
        """
        获取指定行的数据
        :param index: 行索引（从0开始）
        :return: 字典，键为列名，值为数据
        """
        if self.data is None or index < 0 or index >= len(self.data):
            return None
        
        return self.data.iloc[index].to_dict()
    
    def preview_data(self, max_rows=10):
        """
        预览数据
        :param max_rows: 最大预览行数
        :return: 预览数据DataFrame
        """
        if self.data is None:
            return None
        return self.data.head(max_rows)
    
    def is_loaded(self):
        """检查数据是否已加载"""
        return self.data is not None

