"""
V5 Execution Control Module
Fixed workflow executor: Input each field -> Delay -> Enter, then Down Arrow after each row
"""
import pyautogui
import time
import threading
import winsound


class V5WorkflowExecutor:
    def __init__(self, data_loader, callback=None, delay_seconds=1.0, play_sound=True):
        """
        Initialize V5 workflow executor
        :param data_loader: DataLoader instance
        :param callback: Progress callback function, parameters: (current_row, total_rows, message)
        :param delay_seconds: Delay in seconds after each field input (default 1.0)
        :param play_sound: Whether to play sound after each row completion (default True)
        """
        self.data_loader = data_loader
        self.callback = callback
        self.delay_seconds = delay_seconds
        self.play_sound = play_sound
        
        self.is_running = False
        self.should_stop = False
        self.execution_thread = None
        
        # Set pyautogui delay
        pyautogui.PAUSE = 0.1  # Default operation interval 0.1 seconds
    
    def _play_notification_sound(self):
        """
        Play soft notification sound (similar to Tesla sound)
        Use 800Hz frequency, 150ms duration
        """
        if not self.play_sound:
            return
        
        try:
            winsound.Beep(800, 150)
        except Exception:
            # If playback fails (e.g., non-Windows system), silently ignore
            pass
    
    def start(self, start_row=0):
        """
        Start execution
        :param start_row: Row number to start from (0-based, 0 means from first row)
        """
        if self.is_running:
            return False
        
        if not self.data_loader.is_loaded():
            if self.callback:
                self.callback(0, 0, "Error: Please load data file first")
            return False
        
        # Validate start row number
        total_rows = self.data_loader.get_row_count()
        if start_row < 0 or start_row >= total_rows:
            if self.callback:
                self.callback(0, 0, f"Error: Invalid start row (should be between 1-{total_rows})")
            return False
        
        self.is_running = True
        self.should_stop = False
        
        self.execution_thread = threading.Thread(target=self._execute_workflow, args=(start_row,), daemon=True)
        self.execution_thread.start()
        return True
    
    def stop(self):
        """Stop execution"""
        self.should_stop = True
        self.is_running = False
    
    def _execute_workflow(self, start_row):
        """
        Execute workflow (runs in separate thread)
        Fixed workflow for each row:
        1. For each field in the row:
           - Input field value
           - Delay (configurable)
           - Press Enter
        2. After all fields completed:
           - Press Down Arrow
        """
        try:
            total_rows = self.data_loader.get_row_count()
            columns = self.data_loader.get_columns()
            
            if start_row > 0 and self.callback:
                self.callback(0, 0, f"Starting from row {start_row + 1} (total {total_rows} rows)")
            
            for row_index in range(start_row, total_rows):
                if self.should_stop:
                    break
                
                # Get current row data
                row_data = self.data_loader.get_row(row_index)
                if row_data is None:
                    continue
                
                # Process each field in the row
                for field_index, field_name in enumerate(columns):
                    if self.should_stop:
                        break
                    
                    # Get field value
                    if field_name in row_data:
                        field_value = str(row_data[field_name])
                        
                        # Input field value
                        pyautogui.write(field_value, interval=0.05)
                        if self.callback:
                            self.callback(row_index + 1, total_rows, f"Input field {field_name}: {field_value}")
                        
                        # Delay after field input
                        elapsed = 0
                        while elapsed < self.delay_seconds and not self.should_stop:
                            time.sleep(0.1)
                            elapsed += 0.1
                        
                        if self.should_stop:
                            break
                        
                        # Press Enter after field input
                        pyautogui.press('enter')
                        if self.callback:
                            self.callback(row_index + 1, total_rows, f"Pressed Enter after field {field_name}")
                
                # After all fields completed, press Down Arrow
                if not self.should_stop:
                    pyautogui.press('down')
                    if self.callback:
                        self.callback(row_index + 1, total_rows, f"Row {row_index + 1} completed, pressed Down Arrow")
                    
                    # Play notification sound after each row
                    self._play_notification_sound()
            
            # Execution completed
            self.is_running = False
            if self.callback:
                if self.should_stop:
                    self.callback(total_rows, total_rows, "Execution stopped")
                else:
                    self.callback(total_rows, total_rows, "Execution completed")
                    
        except Exception as e:
            self.is_running = False
            if self.callback:
                self.callback(0, 0, f"Execution error: {str(e)}")
    
    def is_executing(self):
        """Check if currently executing"""
        return self.is_running

