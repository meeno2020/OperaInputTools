"""
资源路径工具模块
用于处理 PyInstaller 打包后的资源文件路径
"""
import os
import sys


def resource_path(relative_path):
    """
    获取资源文件的绝对路径
    支持开发环境和 PyInstaller 打包后的环境
    
    :param relative_path: 相对路径
    :return: 绝对路径
    """
    try:
        # PyInstaller 打包后会设置 _MEIPASS 属性
        base_path = sys._MEIPASS
    except AttributeError:
        # 开发环境，使用当前脚本所在目录
        base_path = os.path.abspath(os.path.dirname(__file__))
    
    return os.path.join(base_path, relative_path)


def get_app_dir():
    """
    获取应用程序目录（用于保存配置文件和数据文件）
    在打包后的环境中，应该使用 exe 文件所在目录
    
    :return: 应用程序目录路径
    """
    if getattr(sys, 'frozen', False):
        # PyInstaller 打包后的环境
        # 使用 exe 文件所在目录
        return os.path.dirname(sys.executable)
    else:
        # 开发环境，使用当前脚本所在目录
        return os.path.dirname(os.path.abspath(__file__))


def get_screenshot_dir():
    """
    获取截图保存目录
    在打包后的环境中，截图应该保存在 exe 文件所在目录
    
    :return: 截图目录路径
    """
    app_dir = get_app_dir()
    screenshot_dir = os.path.join(app_dir, "button_screenshots")
    
    # 确保目录存在
    if not os.path.exists(screenshot_dir):
        try:
            os.makedirs(screenshot_dir)
        except Exception as e:
            print(f"创建截图目录失败: {e}")
            # 如果创建失败，使用当前目录
            screenshot_dir = os.path.join(os.getcwd(), "button_screenshots")
            try:
                if not os.path.exists(screenshot_dir):
                    os.makedirs(screenshot_dir)
            except:
                pass
    
    return screenshot_dir

